from cw import VERSION
